def getAlpha():
    alphabet = input("enter a message to encrypt")
    doublealpha = alphabet + alphabet
    return doublealpha
print(getAlpha())