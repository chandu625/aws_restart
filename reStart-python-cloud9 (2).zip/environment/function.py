def getMessage():
    sruthi = input("Please enter a message to encrypt: ")
    alphabet = sruthi + sruthi
    return alphabet
print(getMessage())

